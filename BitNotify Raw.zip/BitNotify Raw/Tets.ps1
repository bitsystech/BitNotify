Import-Module ".\BitNotify.dll"
Start-Sleep 1

#Creating Reading File for UserGUI
Add-Content -Path "C:\Users\jatis\OneDrive\Dokumente\Fiverr\.BitSys Technologies AB\BitNotify\bin\Test.txt" "Enrollment Started"

#Running the Splash Screen
$parameters = @{
    ComputerName = "LocalHost"
    ConfigurationName = 'MySession.PowerShell'
    ScriptBlock = 
    { 
        Import-Module ".\BitNotify.dll";
        Open-SplashScreen -Title "Testing Popup" -SubTitle "This is a Subtle Subtitle" -CoverScreenArea 0.8 -Body "This is the main body text." -BeginReading "C:\Users\jatis\OneDrive\Dokumente\Fiverr\.BitSys Technologies AB\BitNotify\bin\Test.txt" -Timeout 200 -ShowCloseButton $true 
    }
}
Invoke-Command LocalHost -Scriptblock {Import-Module ".\BitNotify.dll" Open-SplashScreen -Title "Testing Popup" -SubTitle "This is a Subtle Subtitle" -CoverScreenArea 0.8 -Body "This is the main body text." -BeginReading "C:\Users\jatis\OneDrive\Dokumente\Fiverr\.BitSys Technologies AB\BitNotify\bin\Test.txt" -Timeout 200 -ShowCloseButton $true } -InDisconnectedSession

Add-Content -Path C:\Windows\UserGUI.txt "ABC"
Start-Sleep 5

Add-Content -Path C:\Windows\UserGUI.txt "XYZ"